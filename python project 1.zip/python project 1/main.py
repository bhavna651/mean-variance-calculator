from mean_var_std import calculate

# Test the function with a list of numbers
print(calculate([0, 1, 2, 3, 4, 5, 6, 7, 8]))
